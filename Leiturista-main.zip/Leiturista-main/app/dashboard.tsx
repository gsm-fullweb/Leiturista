import React, { useState } from "react";
import {
  View,
  ScrollView,
  SafeAreaView,
  Text,
  TouchableOpacity,
} from "react-native";
import { useRouter } from "expo-router";
import { Bell } from "lucide-react-native";

import Header from "../components/Header";
import SyncStatusBar from "../components/SyncStatusBar";
import DashboardMenu from "../components/DashboardMenu";
import RoutesList from "../components/RoutesList";

export default function Dashboard() {
  const router = useRouter();
  const [isOnline, setIsOnline] = useState(true);
  const [pendingUploads, setPendingUploads] = useState(2);
  const [lastSyncTime, setLastSyncTime] = useState("10:30 AM");

  // Mock data for routes
  const routes = [
    {
      id: "1",
      name: "Centro da Cidade",
      completedAddresses: 5,
      totalAddresses: 12,
      estimatedTime: "2 horas",
      isActive: true,
    },
    {
      id: "2",
      name: "Zona Norte Residencial",
      completedAddresses: 0,
      totalAddresses: 18,
      estimatedTime: "3 horas",
    },
    {
      id: "3",
      name: "Parque Industrial",
      completedAddresses: 8,
      totalAddresses: 8,
      estimatedTime: "1.5 horas",
    },
    {
      id: "4",
      name: "Zona Oeste Comercial",
      completedAddresses: 3,
      totalAddresses: 15,
      estimatedTime: "2.5 horas",
    },
  ];

  const handleSyncPress = () => {
    // Simulate sync process
    setIsOnline(true);
    setPendingUploads(0);
    setLastSyncTime(
      new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    );
  };

  const handleCheckSync = () => {
    // Toggle online status for demonstration
    setIsOnline(!isOnline);
  };

  const handleNotificationsPress = () => {
    // Navigate to notifications or show notifications panel
    console.log("Notifications pressed");
  };

  return (
    <SafeAreaView className="flex-1 bg-gray-100">
      <Header title="Painel Principal" isOnline={isOnline} />

      <SyncStatusBar
        isOnline={isOnline}
        lastSyncTime={lastSyncTime}
        pendingUploads={pendingUploads}
        onSyncPress={handleSyncPress}
      />

      <ScrollView className="flex-1 px-4 pt-4">
        {/* Notifications Banner */}
        {pendingUploads > 0 && (
          <TouchableOpacity
            className="bg-amber-100 border border-amber-300 rounded-lg p-3 mb-4 flex-row items-center justify-between"
            onPress={handleNotificationsPress}
          >
            <View className="flex-row items-center">
              <Bell size={18} color="#d97706" />
              <Text className="ml-2 text-amber-800">
                {pendingUploads} leituras pendentes para sincronizar
              </Text>
            </View>
            <Text className="text-amber-600 font-medium">Ver</Text>
          </TouchableOpacity>
        )}

        {/* Welcome Message */}
        <View className="mb-4">
          <Text className="text-2xl font-bold text-gray-800">
            Olá, Leiturista
          </Text>
          <Text className="text-gray-600">
            Bem-vindo ao seu painel de controle
          </Text>
        </View>

        {/* Dashboard Menu */}
        <DashboardMenu onCheckSync={handleCheckSync} />

        {/* Daily Stats Summary */}
        <View className="bg-white rounded-lg shadow-sm p-4 my-4">
          <Text className="text-lg font-semibold mb-3 text-gray-800">
            Resumo do Dia
          </Text>
          <View className="flex-row justify-between">
            <View className="items-center">
              <Text className="text-2xl font-bold text-blue-600">16</Text>
              <Text className="text-sm text-gray-600">Leituras Totais</Text>
            </View>
            <View className="items-center">
              <Text className="text-2xl font-bold text-green-600">13</Text>
              <Text className="text-sm text-gray-600">Completadas</Text>
            </View>
            <View className="items-center">
              <Text className="text-2xl font-bold text-amber-600">3</Text>
              <Text className="text-sm text-gray-600">Pendentes</Text>
            </View>
          </View>
        </View>

        {/* Routes List */}
        <View className="mb-4">
          <RoutesList routes={routes} />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}
