import React from "react";
import { View, Text, ScrollView, SafeAreaView, StatusBar } from "react-native";
import { useRouter } from "expo-router";
import { ArrowLeft } from "lucide-react-native";
import { TouchableOpacity } from "react-native-gesture-handler";

import ProfileHeader from "../components/ProfileHeader";
import DailyStats from "../components/DailyStats";
import AppSettings from "../components/AppSettings";

export default function ProfileScreen() {
  const router = useRouter();

  const handleLogout = () => {
    // In a real app, this would handle authentication logout
    console.log("Logging out...");
    router.replace("/");
  };

  const handleBackPress = () => {
    router.back();
  };

  return (
    <SafeAreaView className="flex-1 bg-gray-100">
      <StatusBar barStyle="dark-content" backgroundColor="#f3f4f6" />

      {/* Header with back button */}
      <View className="flex-row items-center px-4 py-3 bg-white border-b border-gray-200">
        <TouchableOpacity onPress={handleBackPress} className="mr-3">
          <ArrowLeft size={24} color="#3b82f6" />
        </TouchableOpacity>
        <Text className="text-xl font-bold text-gray-800">My Profile</Text>
      </View>

      <ScrollView className="flex-1 p-4">
        {/* Profile Header Section */}
        <ProfileHeader
          userName="Alex Johnson"
          userId="MR-7842"
          role="Senior Meter Reader"
          avatarUrl="https://api.dicebear.com/7.x/avataaars/svg?seed=alex"
          onEditProfile={() => console.log("Edit profile")}
        />

        <View className="h-4" />

        {/* Daily Statistics Section */}
        <DailyStats
          completedReadings={32}
          pendingReadings={5}
          averageTimePerReading={2.8}
          issuesReported={1}
          efficiencyRate={92}
        />

        <View className="h-4" />

        {/* App Settings Section */}
        <View className="bg-white rounded-lg shadow-sm overflow-hidden">
          <AppSettings
            onLogout={handleLogout}
            syncFrequency={10}
            dataSavingMode={true}
            darkMode={false}
            cameraResolution="high"
            notificationsEnabled={true}
            autoSync={true}
          />
        </View>

        <View className="h-8" />
      </ScrollView>
    </SafeAreaView>
  );
}
