import React, { useState, useEffect } from "react";
import { View, Text, TouchableOpacity, ScrollView } from "react-native";
import { useLocalSearchParams } from "expo-router";
import { MapPin, List, Map, ArrowLeft } from "lucide-react-native";
import RouteMap from "../../components/RouteMap";
import AddressList from "../../components/AddressList";

interface Address {
  id: string;
  address: string;
  streetName: string;
  houseNumber: string;
  completed: boolean;
  hasIssue: boolean;
  latitude: number;
  longitude: number;
}

const RouteDetailPage = () => {
  const { id } = useLocalSearchParams();
  const [viewMode, setViewMode] = useState<"map" | "list">("map");
  const [selectedAddressId, setSelectedAddressId] = useState<string | null>(
    null,
  );
  const [routeData, setRouteData] = useState<{
    routeName: string;
    addresses: Address[];
    completionStatus: {
      total: number;
      completed: number;
    };
  }>({
    routeName: `Route ${id || "404"}`,
    addresses: [
      {
        id: "1",
        address: "123 Oak Street",
        streetName: "Oak Street",
        houseNumber: "123",
        completed: true,
        hasIssue: false,
        latitude: 40.7128,
        longitude: -74.006,
      },
      {
        id: "2",
        address: "456 Oak Street",
        streetName: "Oak Street",
        houseNumber: "456",
        completed: false,
        hasIssue: false,
        latitude: 40.7142,
        longitude: -74.0064,
      },
      {
        id: "3",
        address: "789 Maple Avenue",
        streetName: "Maple Avenue",
        houseNumber: "789",
        completed: false,
        hasIssue: true,
        latitude: 40.7112,
        longitude: -74.0055,
      },
      {
        id: "4",
        address: "101 Pine Road",
        streetName: "Pine Road",
        houseNumber: "101",
        completed: false,
        hasIssue: false,
        latitude: 40.7135,
        longitude: -74.0046,
      },
      {
        id: "5",
        address: "202 Pine Road",
        streetName: "Pine Road",
        houseNumber: "202",
        completed: true,
        hasIssue: false,
        latitude: 40.7145,
        longitude: -74.0039,
      },
    ],
    completionStatus: {
      total: 5,
      completed: 2,
    },
  });

  useEffect(() => {
    // In a real app, fetch route data based on the ID
    // For now, we're using mock data initialized above
    if (routeData.addresses.length > 0 && !selectedAddressId) {
      setSelectedAddressId(routeData.addresses[0].id);
    }
  }, [id]);

  const handleAddressSelect = (addressId: string) => {
    setSelectedAddressId(addressId);
    // If in list view, switch to map view to show the selected location
    if (viewMode === "list") {
      setViewMode("map");
    }
  };

  const handleNavigateToMeter = (addressId: string) => {
    // In a real app, navigate to the meter reading screen
    console.log(`Navigate to meter reading for address ${addressId}`);
    // Example navigation:
    // router.push(`/meter/${addressId}`);
  };

  // Convert addresses to locations for the map
  const mapLocations = routeData.addresses.map((addr) => ({
    id: addr.id,
    address: addr.address,
    latitude: addr.latitude,
    longitude: addr.longitude,
    completed: addr.completed,
  }));

  return (
    <View className="flex-1 bg-gray-50">
      {/* Header */}
      <View className="bg-white pt-12 pb-4 px-4 shadow-sm">
        <View className="flex-row items-center justify-between">
          <TouchableOpacity
            className="p-2"
            // In a real app, navigate back to dashboard
            // onPress={() => router.back()}
          >
            <ArrowLeft size={24} color="#374151" />
          </TouchableOpacity>

          <Text className="text-xl font-bold text-gray-800">
            {routeData.routeName}
          </Text>

          <View className="w-10" />
        </View>

        <View className="mt-2 flex-row justify-between items-center">
          <View className="flex-row items-center">
            <MapPin size={16} color="#4b5563" />
            <Text className="ml-1 text-gray-600">
              {routeData.addresses.length} addresses
            </Text>
          </View>

          <View className="bg-blue-50 px-3 py-1 rounded-full">
            <Text className="text-blue-700 font-medium">
              {routeData.completionStatus.completed}/
              {routeData.completionStatus.total} completed
            </Text>
          </View>
        </View>
      </View>

      {/* View Toggle */}
      <View className="flex-row bg-gray-100 mx-4 mt-4 rounded-lg p-1">
        <TouchableOpacity
          onPress={() => setViewMode("map")}
          className={`flex-1 flex-row items-center justify-center py-2 px-4 rounded-md ${viewMode === "map" ? "bg-white shadow-sm" : ""}`}
        >
          <Map size={18} color={viewMode === "map" ? "#3b82f6" : "#6b7280"} />
          <Text
            className={`ml-2 ${viewMode === "map" ? "text-blue-600 font-medium" : "text-gray-600"}`}
          >
            Map
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          onPress={() => setViewMode("list")}
          className={`flex-1 flex-row items-center justify-center py-2 px-4 rounded-md ${viewMode === "list" ? "bg-white shadow-sm" : ""}`}
        >
          <List size={18} color={viewMode === "list" ? "#3b82f6" : "#6b7280"} />
          <Text
            className={`ml-2 ${viewMode === "list" ? "text-blue-600 font-medium" : "text-gray-600"}`}
          >
            List
          </Text>
        </TouchableOpacity>
      </View>

      {/* Content based on view mode */}
      <View className="flex-1 mt-4">
        {viewMode === "map" ? (
          <View className="px-4">
            <RouteMap
              locations={mapLocations}
              currentLocationId={selectedAddressId || undefined}
              onLocationSelect={handleAddressSelect}
            />

            {/* Quick access to selected address */}
            {selectedAddressId && (
              <View className="mt-4 bg-white rounded-lg p-4 shadow-sm border border-gray-200">
                <Text className="text-gray-800 font-medium mb-1">
                  Selected Address
                </Text>

                {(() => {
                  const selectedAddress = routeData.addresses.find(
                    (addr) => addr.id === selectedAddressId,
                  );

                  if (!selectedAddress) return null;

                  return (
                    <View>
                      <Text className="text-gray-900 font-bold text-lg">
                        {selectedAddress.address}
                      </Text>
                      <View className="flex-row justify-between items-center mt-2">
                        <Text className="text-gray-600">
                          {selectedAddress.completed
                            ? "Completed"
                            : "Not completed"}
                          {selectedAddress.hasIssue ? " • Has issues" : ""}
                        </Text>
                        <TouchableOpacity
                          onPress={() =>
                            handleNavigateToMeter(selectedAddress.id)
                          }
                          className="bg-blue-500 py-2 px-4 rounded-lg"
                        >
                          <Text className="text-white font-medium">
                            Go to Meter
                          </Text>
                        </TouchableOpacity>
                      </View>
                    </View>
                  );
                })()}
              </View>
            )}
          </View>
        ) : (
          <AddressList
            addresses={routeData.addresses}
            onAddressPress={handleAddressSelect}
            onNavigatePress={handleNavigateToMeter}
            showSearch={true}
            showFilters={true}
            groupByStreet={true}
          />
        )}
      </View>
    </View>
  );
};

export default RouteDetailPage;
